package com.example.ticketAppOU;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketAppOuApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketAppOuApplication.class, args);
	}

}
