package com.ilgo.ticketapp.entity;

public class Yonetici extends Kullanici {

    public Yonetici() {

        super();

    }

    public Yonetici(String id, String adSoyad, String email, String sifre) {

        super(id, adSoyad, email, sifre);

    }

}
