package com.example.ticketAppOU;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketAppOuApplicationTests {

	@Test
	void contextLoads() {
	}

}
